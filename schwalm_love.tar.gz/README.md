CS640 - Assignment 4 (Spring 2015)

Partner 1: Corbin Schwalm | CS Login: schwalm
Partner 2: Joshua Love | CS Login: love

For this assignment, you will explore how DNS, clouds, and CDNs play a role in accessing websites. You’ll then write your own simple DNS server that performs recursive DNS resolutions, and appends a special annotation if an IP address belongs to an Amazon EC2 region.

http://pages.cs.wisc.edu/~agember/cs640/s15/assign4/
